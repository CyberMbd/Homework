
const connection = require('../db');
const malzeme = require('../models/malzeme');


// POST -> /malzeme/ekle
exports.malzeme_ekle = async (req, res) => {
    try {
        const yeniMalzeme = new malzeme(req.body.id, req.body.ad);
        const malzemeEkle = await connection.query("INSERT INTO malzeme (malzeme_id, malzeme_adi) VALUES ($1, $2)", [yeniMalzeme.id, yeniMalzeme.ad]);

        res.json("Malzeme ekleme basarili");
    } catch (err) {
        console.log(err.message);
    }
};

// PUT -> /malzeme/guncelle
exports.malzeme_guncelle = async (req, res) => {
    try {
        const guncelMalzeme = new malzeme(req.body.id, req.body.ad);
        const malzemeGuncelle = await connection.query("UPDATE malzeme SET malzeme_adi= $1 WHERE malzeme_id = $2", [guncelMalzeme.ad, guncelMalzeme.id]);

        res.json("Malzeme guncelleme basarili");
    } catch (err) {
        console.log(err.message);
    }
};

// DELETE -> /malzeme/sil
exports.malzeme_sil = async (req, res) => {
    try {
        const id = req.body.id;
        const malzemeSil = await connection.query("DELETE FROM malzeme WHERE malzeme_id = $1", [id]);

        res.json("Malzeme silme basarili");
    } catch (err) {
        console.log(err.message);
    }
};