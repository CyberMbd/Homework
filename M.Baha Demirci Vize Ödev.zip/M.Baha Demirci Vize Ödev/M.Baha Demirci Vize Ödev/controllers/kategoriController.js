
const connection = require('../db');
const kategori = require('../models/kategori');



// POST -> /kategori/ekle
exports.kategori_ekle = async (req, res) => {
    try {
        const yeniKategori = new kategori(req.body.id, req.body.ad);
        const kategoriEkle = await connection.query("INSERT INTO kategori (kategori_id, kategori_adi) VALUES ($1, $2)", [yeniKategori.id, yeniKategori.ad]);

        res.json("Kategori ekleme basarili");
    } catch (err) {
        console.log(err.message);
    }
};

// PUT -> /kategori/guncelle
exports.kategori_guncelle = async (req, res) => {
    try {
        const guncelKategori = new kategori(req.body.id, req.body.ad);
        const kategoriGuncelle = await connection.query("UPDATE kategori SET kategori_adi= $1 WHERE kategori_id = $2", [guncelKategori.ad, guncelKategori.id]);

        res.json("Kategori guncelleme basarili");
    } catch (err) {
        console.log(err.message);
    }
};

// DELETE -> /kategori/sil
exports.kategori_sil = async (req, res) => {
    try {
        const id = req.body.id;
        const kategoriSil = await connection.query("DELETE FROM kategori WHERE kategori_id = $1", [id]);

        res.json("Kategori silme basarili");
    } catch (err) {
        console.log(err.message);
    }
};