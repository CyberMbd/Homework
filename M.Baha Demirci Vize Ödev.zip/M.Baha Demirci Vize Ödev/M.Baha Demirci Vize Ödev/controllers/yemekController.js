
const connection = require('../db');
const tarif = require('../models/tarif');


// POST -> /tarif/ekle
exports.tarif_ekle = async (req, res) => {
    try {
        const yeniTarif = new tarif(req.body.id, req.body.uye_id, req.body.malzeme_id, req.body.adet, req.body.kategori_id);
        const tarifEkle = await connection.query("INSERT INTO yemek_tarifleri (tarif_id, uye_id, malzeme_id, adet, kategori_id) VALUES ($1, $2, $3, $4, $5)", [yeniTarif.id, yeniTarif.uye_id, yeniTarif.malzeme_id, yeniTarif.adet, yeniTarif.kategori_id]);

        console.log(yeniTarif);
        res.json("Tarif ekleme basarili");
    } catch (err) {
        console.log(err.message);
    }
};

// PUT -> /tarif/guncelle
exports.tarif_guncelle = async (req, res) => {
    try {
        const guncelTarif = new tarif(req.body.id, req.body.uye_id, req.body.malzeme_id, req.body.adet, req.body.kategori_id);
        const tarifGuncelle = await connection.query("UPDATE yemek_tarifleri SET uye_id = $1, malzeme_id = $2, adet = $3, kategori_id = $4 WHERE tarif_id = $5", [guncelTarif.uye_id, guncelTarif.malzeme_id, guncelTarif.adet, guncelTarif.kategori_id, guncelTarif.id]);

        res.json("tarif guncelleme basarili");
    } catch (err) {
        console.log(err.message);
    }
};

// DELETE -> /tarif/sil
exports.tarif_sil = async (req, res) => {
    try {
        const id = req.body.id;
        const tarifSil = await connection.query("DELETE FROM yemek_tarifleri WHERE tarif_id = $1", [id]);

        res.json("tarif silme basarili");
    } catch (err) {
        console.log(err.message);
    }
};