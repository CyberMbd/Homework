
const connection = require('../db');
const uye = require('../models/uye');
const crypto = require('crypto')



// POST -> /uye/ekle
exports.uye_ekle = async (req, res) => {
    try {
        // Simdiki tarih ve saat bilgilerini aliyoruz
        let simdi = Date.now();
        let tarih_saat = new Date(simdi);
        let tarih = [tarih_saat.getFullYear(), tarih_saat.getMonth(), tarih_saat.getDate()].join("-");
        let saat = [tarih_saat.getHours(), tarih_saat.getMinutes()].join(":");

        // Crypto kutuphanesi ile parola icin SHA1 hash aliyoruz
        const parola_hash = crypto.createHash("sha1").update(req.body.parola).digest('hex');
        console.log(parola_hash);

        const yeniUye = new uye(req.body.id, req.body.ad, req.body.eposta, parola_hash, tarih, saat);        

        const uyeKaydet = await connection.query("INSERT INTO uyeler (uye_id, uye_adi, eposta, parola, tarih, saat) VALUES ($1, $2, $3, $4, $5, $6)", [yeniUye.id, yeniUye.ad, yeniUye.eposta, yeniUye.parola, yeniUye.tarih, yeniUye.saat]);

        res.json("Kayit basarili");
    } catch (err) {
        console.log(err.message);
    }
};