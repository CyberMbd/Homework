

exports.anasayfa_get = (req, res) => {
    res.send("Anasayfa");
  };