class Tarif {
    id;
    uyeId;
    malzemeId;
    adet;
    kategoriId;

    constructor(id, uyeId, malzemeId, adet, kategoriId) {
        this.id = id;
        this.uyeId = uyeId;
        this.malzemeId = malzemeId;
        this.adet = adet;
        this.kategoriId = kategoriId;
    }
}

module.exports = Tarif;