class Uye {
    id;
    ad;
    eposta;
    parola;
    tarih;
    saat;

    constructor(id, ad, eposta, parola, tarih, saat) {
        this.id = id;
        this.ad = ad;
        this.eposta = eposta;
        this.parola = parola;
        this.tarih = tarih;
        this.saat = saat;
    }
}

module.exports = Uye;