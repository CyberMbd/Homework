class Malzeme {
    id;
    ad;

    constructor(id, ad) {
        this.id = id;
        this.ad = ad;
    }
}

module.exports = Malzeme;