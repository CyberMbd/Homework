const express = require("express");
const router = express.Router();
const bodyParser = require('body-parser');

//middleware
router.use(bodyParser.json());
router.use(bodyParser.urlencoded({extended: false}));

// Controller Modülünü Çağırıyoruz
const anasayfa_controller = require("../controllers/anasayfaController");
const uye_controller = require("../controllers/uyeController");
const yemek_controller = require("../controllers/yemekController");
const kategori_controller = require("../controllers/kategoriController");
const malzeme_controller = require("../controllers/malzemeController");

// Anasayfa için GET isteği
router.get("/", anasayfa_controller.anasayfa_get);

// Üye oluşturmak için POST isteği
router.post("/uye/ekle", uye_controller.uye_ekle);

// /tarif/ekle
router.post("/tarif/ekle", yemek_controller.tarif_ekle);
// /tarif/guncelle
router.put("/tarif/guncelle", yemek_controller.tarif_guncelle);
// /tarif/sil
router.delete("/tarif/sil", yemek_controller.tarif_sil);

// /kategori/ekle
router.post("/kategori/ekle", kategori_controller.kategori_ekle);
// /kategori/guncelle
router.put("/kategori/guncelle", kategori_controller.kategori_guncelle);
// /kategori/sil
router.delete("/kategori/sil", kategori_controller.kategori_sil);

// /malzeme/ekle
router.post("/malzeme/ekle", malzeme_controller.malzeme_ekle);
// /malzeme/guncelle
router.put("/malzeme/guncelle", malzeme_controller.malzeme_guncelle);
// /malzeme/sil
router.delete("/malzeme/sil", malzeme_controller.malzeme_sil);

module.exports = router;