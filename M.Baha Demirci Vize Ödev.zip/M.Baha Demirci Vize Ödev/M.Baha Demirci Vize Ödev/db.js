var Pool = require('pg').Pool;

var dbHost = "127.0.0.1";
var dbUser= "postgres";
var dbPassword = "postgres";
var dbDatabase= "ubybs23";

const connection = new Pool({
    host: dbHost,
    user: dbUser,
    password: dbPassword,
    port: 5432,
    database: dbDatabase
});

module.exports = connection;
