--
-- PostgreSQL database dump
--

-- Dumped from database version 14.7 (Ubuntu 14.7-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.7 (Ubuntu 14.7-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: kategori; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.kategori (
    kategori_id integer NOT NULL,
    kategori_adi character varying
);


ALTER TABLE public.kategori OWNER TO postgres;

--
-- Name: malzeme; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.malzeme (
    malzeme_id integer NOT NULL,
    malzeme_adi character varying
);


ALTER TABLE public.malzeme OWNER TO postgres;

--
-- Name: uyeler; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.uyeler (
    uye_id integer NOT NULL,
    uye_adi character varying(250),
    eposta character varying(250),
    parola character varying(250),
    tarih date,
    saat character varying(5)
);


ALTER TABLE public.uyeler OWNER TO postgres;

--
-- Name: yemek_tarifleri; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.yemek_tarifleri (
    tarif_id integer NOT NULL,
    uye_id integer,
    malzeme_id integer,
    adet integer,
    kategori_id integer
);


ALTER TABLE public.yemek_tarifleri OWNER TO postgres;

--
-- Data for Name: kategori; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.kategori (kategori_id, kategori_adi) FROM stdin;
1	Çorba
\.


--
-- Data for Name: malzeme; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.malzeme (malzeme_id, malzeme_adi) FROM stdin;
1	Patates
\.


--
-- Data for Name: uyeler; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.uyeler (uye_id, uye_adi, eposta, parola, tarih, saat) FROM stdin;
1	User1	user@example.com	7c4a8d09ca3762af61e59520943dc26494f8941b	2023-04-15	18:42
2	User2	user2@example.com	7c4a8d09ca3762af61e59520943dc26494f8941b	2023-04-15	18:45
3	Baha	baha@demirci.com	8cb2237d0679ca88db6464eac60da96345513964	2023-04-18	9:51
\.


--
-- Data for Name: yemek_tarifleri; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.yemek_tarifleri (tarif_id, uye_id, malzeme_id, adet, kategori_id) FROM stdin;
1	\N	\N	6	\N
2	\N	\N	10	\N
\.


--
-- Name: kategori kategori_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.kategori
    ADD CONSTRAINT kategori_pkey PRIMARY KEY (kategori_id);


--
-- Name: malzeme malzeme_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.malzeme
    ADD CONSTRAINT malzeme_pkey PRIMARY KEY (malzeme_id);


--
-- Name: uyeler uyeler_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.uyeler
    ADD CONSTRAINT uyeler_pkey PRIMARY KEY (uye_id);


--
-- Name: yemek_tarifleri yemek_tarifleri_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.yemek_tarifleri
    ADD CONSTRAINT yemek_tarifleri_pkey PRIMARY KEY (tarif_id);


--
-- PostgreSQL database dump complete
--

